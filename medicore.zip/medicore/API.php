<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// 1. ڈیٹا بیس کنکشن
$conn = new mysqli("localhost", "root", "", "medicore_hms");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Connection Failed: " . $conn->connect_error]);
    exit();
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

if (empty($action)) {
    echo json_encode(["status" => "error", "message" => "No action specified"]);
    exit();
}

// ==================== GET DATA ====================
if ($action == "get_patients") { fetchData($conn, "patients"); }
if ($action == "get_doctors") { fetchData($conn, "doctors"); }
if ($action == "get_appointments") { fetchData($conn, "appointments"); }
if ($action == "get_billing") { fetchData($conn, "billing"); }

// ==================== ADD DATA ====================
if ($action == "add_patients") {
    $patient_code = $_POST['patient_code'] ?? '';
    $name = $_POST['name'] ?? '';
    $age = !empty($_POST['age']) ? intval($_POST['age']) : 0;
    $gender = $_POST['gender'] ?? '';
    $blood_group = $_POST['blood_group'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $disease = $_POST['disease'] ?? '';
    $admitted = $_POST['admitted'] ?? '';

    $query = "INSERT INTO patients (patient_code, name, age, gender, blood_group, phone, address, disease, admitted) VALUES ('$patient_code', '$name', $age, '$gender', '$blood_group', '$phone', '$address', '$disease', '$admitted')";
    executeRawQuery($conn, $query, "Patient Added Successfully");
}

if ($action == "add_doctors") {
    $doctor_code = $_POST['doctor_code'] ?? '';
    $name = $_POST['name'] ?? '';
    $specialization = $_POST['specialization'] ?? '';
    $qualification = $_POST['qualification'] ?? '';
    $fee = !empty($_POST['fee']) ? floatval($_POST['fee']) : 0.00;
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $status = $_POST['status'] ?? '';

    $query = "INSERT INTO doctors (doctor_code, name, specialization, qualification, fee, phone, email, status) VALUES ('$doctor_code', '$name', '$specialization', '$qualification', $fee, '$phone', '$email', '$status')";
    executeRawQuery($conn, $query, "Doctor Added Successfully");
}

if ($action == "add_appointments") {
    $appointment_no = $_POST['appointment_no'] ?? '';
    $patient_id = intval($_POST['patient_id'] ?? 0);
    $doctor_id = intval($_POST['doctor_id'] ?? 0);
    $appointment_date = $_POST['appointment_date'] ?? '';
    $appointment_time = $_POST['appointment_time'] ?? '';
    $token_no = !empty($_POST['token_no']) ? intval($_POST['token_no']) : 0;
    $status = $_POST['status'] ?? '';
    $remarks = $_POST['remarks'] ?? '';

    $query = "INSERT INTO appointments (appointment_no, patient_id, doctor_id, appointment_date, appointment_time, token_no, status, remarks) VALUES ('$appointment_no', $patient_id, $doctor_id, '$appointment_date', '$appointment_time', $token_no, '$status', '$remarks')";
    executeRawQuery($conn, $query, "Appointment Scheduled Successfully");
}

if ($action == "add_billing") {
    $bill_no = $_POST['bill_no'] ?? '';
    $patient_id = intval($_POST['patient_id'] ?? 0);
    $doctor_id = intval($_POST['doctor_id'] ?? 0);
    $consultation_fee = floatval($_POST['consultation_fee'] ?? 0);
    $medicine_fee = floatval($_POST['medicine_fee'] ?? 0);
    $test_fee = floatval($_POST['test_fee'] ?? 0);
    $other_charges = floatval($_POST['other_charges'] ?? 0);
    $total_amount = floatval($_POST['total_amount'] ?? 0);
    $payment_status = $_POST['payment_status'] ?? '';
    $payment_method = $_POST['payment_method'] ?? '';
    $bill_date = $_POST['bill_date'] ?? '';

    $query = "INSERT INTO billing (bill_no, patient_id, doctor_id, consultation_fee, medicine_fee, test_fee, other_charges, total_amount, payment_status, payment_method, bill_date) VALUES ('$bill_no', $patient_id, $doctor_id, $consultation_fee, $medicine_fee, $test_fee, $other_charges, $total_amount, '$payment_status', '$payment_method', '$bill_date')";
    executeRawQuery($conn, $query, "Bill Generated Successfully");
}

// ==================== DELETE DATA ====================
if (strpos($action, 'delete_') === 0) {
    $table = str_replace('delete_', '', $action);
    $id = intval($_POST['id'] ?? 0);
    $query = "DELETE FROM `$table` WHERE id = $id";
    executeRawQuery($conn, $query, "Record Deleted Successfully");
}

// ==================== FUNCTIONS ====================
function fetchData($conn, $table) {
    $result = $conn->query("SELECT * FROM `$table` ORDER BY id DESC");
    $rows = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) { $rows[] = $row; }
        echo json_encode(["status" => "success", "data" => $rows]);
    } else {
        echo json_encode(["status" => "error", "message" => $conn->error]);
    }
    exit();
}

function executeRawQuery($conn, $query, $success_msg) {
    if ($conn->query($query) === TRUE) {
        echo json_encode(["status" => "success", "message" => $success_msg]);
    } else {
        echo json_encode(["status" => "error", "message" => "SQL Error: " . $conn->error]);
    }
    exit();
}

$conn->close();
?>