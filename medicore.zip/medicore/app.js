//open path to show data on the the front page
const API_URL = "./API.php"; 

const content = document.getElementById("content");
const modal = document.getElementById("modal");
const modalTitle = document.getElementById("modalTitle");
const mainForm = document.getElementById("mainForm");
const closeModalBtn = document.getElementById("closeModal");

let currentView = "patients";

//fist show patients data
window.onload =() =>{
    loadData("patients");
};

if (closeModalBtn) {
    closeModalBtn.addEventListener("click", () => {
        modal.classList.add("hidden");
    });
}

// load data from servsr
async function loadData(view) {
    currentView = view;
    content.innerHTML = `<h2 style="color: #4b5563;">Loading ${view}...</h2>`;

    try {
        const response = await fetch(`${API_URL}?action=get_${view}`);
        
        // to check if we got JSON response or HTML (in case of error)
        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
            throw new TypeError("Oops, inside JS we got HTML instead of JSON response!");
        }

        const data = await response.json();

        if (data.status === "success") {
            renderTable(view, data.data);
        } else {
            content.innerHTML = `<h2 style="color:red;">Error: ${data.message}</h2>`;
        }
    } catch (error) {
        console.error(error);
        content.innerHTML = `<h2 style="color:red;">Connection Error: Cannot reach api.php or database failed.</h2>`;
    }
}

// make table
function renderTable(view, rows) {
    let html = `
    <div class="view-header">
        <h2 style="text-transform:capitalize;">${view} Management</h2>
        <button class="add-btn" onclick="openAddModal('${view}')">Add New</button>
    </div>`;

    if (!rows || rows.length === 0) {
        html += `<div class="table-container"><p class="no-data">No Records Found.</p></div>`;
        content.innerHTML = html;
        return;
    }

    html += `<div class="table-container"><table><thead><tr>`;
    Object.keys(rows[0]).forEach(key => {
        html += `<th>${key.replace(/_/g, ' ')}</th>`;
    });
    html += `<th>Actions</th></tr></thead><tbody>`;

    rows.forEach(row => {
        html += `<tr>`;
        Object.values(row).forEach(value => {
            html += `<td>${value !== null ? value : ''}</td>`;
        });
        html += `
        <td>
            <button class="action-btn delete-btn" onclick="deleteRecord('${view}', ${row.id})">
                <i class="fa-solid fa-trash"></i>
            </button>
        </td></tr>`;
    });

    html += `</tbody></table></div>`;
    content.innerHTML = html;
}

// open add modal
function openAddModal(view) {
    modal.classList.remove("hidden");
    modalTitle.innerText = `Add ${view.charAt(0).toUpperCase() + view.slice(1)}`;
    let fields = "";

    if (view === "patients") {
        fields = `
        <input type="text" name="patient_code" placeholder="Patient Code" required>
        <input type="text" name="name" placeholder="Patient Name" required>
        <input type="number" name="age" placeholder="Age">
        <input type="text" name="gender" placeholder="Gender">
        <input type="text" name="blood_group" placeholder="Blood Group">
        <input type="text" name="phone" placeholder="Phone">
        <textarea name="address" placeholder="Address"></textarea>
        <input type="text" name="disease" placeholder="Disease">
        <input type="text" name="admitted" placeholder="Admitted (Yes/No)">`;
    } 
    else if (view === "doctors") {
        fields = `
        <input type="text" name="doctor_code" placeholder="Doctor Code" required>
        <input type="text" name="name" placeholder="Doctor Name" required>
        <input type="text" name="specialization" placeholder="Specialization">
        <input type="text" name="qualification" placeholder="Qualification">
        <input type="number" step="0.01" name="fee" placeholder="Doctor Fee">
        <input type="text" name="phone" placeholder="Phone">
        <input type="email" name="email" placeholder="Email">
        <input type="text" name="status" placeholder="Status">`;
    } 
    else if (view === "appointments") {
        fields = `
        <input type="text" name="appointment_no" placeholder="Appointment No" required>
        <input type="number" name="patient_id" placeholder="Patient ID (Numeric)" required>
        <input type="number" name="doctor_id" placeholder="Doctor ID (Numeric)" required>
        <input type="date" name="appointment_date" required>
        <input type="time" name="appointment_time" required>
        <input type="number" name="token_no" placeholder="Token No">
        <input type="text" name="status" placeholder="Status">
        <textarea name="remarks" placeholder="Remarks"></textarea>`;
    } 
    else if (view === "billing") {
        fields = `
        <input type="text" name="bill_no" placeholder="Bill No" required>
        <input type="number" name="patient_id" placeholder="Patient ID" required>
        <input type="number" name="doctor_id" placeholder="Doctor ID" required>
        <input type="number" step="0.01" name="consultation_fee" placeholder="Consultation Fee">
        <input type="number" step="0.01" name="medicine_fee" placeholder="Medicine Fee">
        <input type="number" step="0.01" name="test_fee" placeholder="Test Fee">
        <input type="number" step="0.01" name="other_charges" placeholder="Other Charges">
        <input type="number" step="0.01" name="total_amount" placeholder="Total Amount" required>
        <input type="text" name="payment_status" placeholder="Payment Status">
        <input type="text" name="payment_method" placeholder="Payment Method">
        <input type="date" name="bill_date" required>`;
    }

    mainForm.innerHTML = `
        ${fields}
        <input type="hidden" name="action" value="add_${view}">
        <button type="submit" class="submit-btn">Save Record</button>
    `;
}

// to save record (add new)
mainForm.addEventListener("submit", async function(e) {
    e.preventDefault();
    const formData = new FormData(mainForm);

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            body: formData
        });
        const data = await response.json();
        alert(data.message);
        if (data.status === "success") {
            modal.classList.add("hidden");
            loadData(currentView);
        }
    } catch(error) {
        console.error(error);
        alert("Failed to save record. Check if api.php path is correct.");
    }
});

// to delete record
async function deleteRecord(view, id) {
    if (!confirm("Are you sure?")) return;
    const formData = new FormData();
    formData.append("action", `delete_${view}`);
    formData.append("id", id);

    try {
        const response = await fetch(API_URL, { method: "POST", body: formData });
        const data = await response.json();
        alert(data.message);
        loadData(view);
    } catch (error) {
        console.error(error);
    }
}